function [IsoLiq] = IsoLiq_E8calc(cWRi, mWRi, isoWRi, m_Rst, cRst, isoRst, mLiq, cLiq, mPeri, cPeri)
%function [IsoLiq] = IsoLiq_E8calc(cWRi, mWRi, isoWRi, m_Rst, cRst, isoRst, mLiq, cLiq, mPeri, cPeri)
%   Uses Eqn. 8 in Appdx E (Isotopic disequilibrium Appendix for Chaos
%   Crags Chp) to calculate isotopic signature of newly-generated anatectic
%   melt DURING AFC step

t1 = cWRi .* mWRi .* isoWRi;
t2 = m_Rst .* cRst .* isoRst;
t3 = mLiq(1) .* cLiq;
t4 = mLiq(2) .* cLiq;
t5 = mPeri .* cPeri;


n = t1 - sum(t2);
d = t3 + t4 + sum(t5);
IsoLiq = n ./ d;



end

