function [cPeri] = cPeriCalc(cLiq, mPer, KdTE)
%function [cPeri] = cPeriCalc(cLiq, mPer, KdTE)
%   Calculates TE concentrations for the NEWLY-GROWN peritectic phases 


c_ALLmins = KdTE .* cLiq;
IdxP = mPer == 0;
cPeri = zeros(size(c_ALLmins));

for i = 3:size(mPer,1)
    if IdxP(i,1) == 0
        cPeri(i,:) = c_ALLmins(i,:);
    elseif IdxP(i) == 1
    end
end   

end

