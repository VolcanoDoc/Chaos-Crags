function [IsoWR_bulk] = IsoWRsys_calc(cWRi, mWRi, IsoWRi, cTEliq, mLiq, IsoLiq, m_Rst, mPer1, cWRbulk)
%function [IsoWR_bulk] = IsoWRsys_calc(cWRi, mWRi, IsoWRi, cTEliq, mLiq, IsoLiq, m_Rst, mPer1, cWRbulk)
%   Uses Eqn6 in Appdx E (Isotopic disequilibrium Appendix for Chaos Crags Chp) to calculate  cTE in the new WR subsystem AFTER AFC in MCs | "t" variables refer to individual terms in the Eqn.


t1 = cWRi .* mWRi .* IsoWRi;
t2 = mLiq(1) .* cTEliq .* IsoLiq;
t3 = (sum(m_Rst) + sum(mPer1) + mLiq(2)) .* cWRbulk;

IsoWR_bulk = (t1 - t2) ./ t3;


end

