function [cWR_bulk] = cWR_E3calc(cWRi, mWRi, cTEliq, mLiq, m_Rst, mPer1)
%function [cWR_bulk] = cLiq_E3calc(cWRi, mWRi, cTEliq, Liq, m_Rst)
%   Uses Eqn3 in Appdx E (Isotopic disequilibrium Appendix for Chaos Crags
%   Chp) to calculate cTE in the new WR subsystem AFTER AFC in MCs | "t" variables refer to individual terms in the Eqn.


t1 = cWRi .* mWRi;
t2 = mLiq(1) .* cTEliq;
t3 = sum(m_Rst) + sum(mPer1) + mLiq(2);

cWR_bulk = (t1 - t2) ./ t3;


end

