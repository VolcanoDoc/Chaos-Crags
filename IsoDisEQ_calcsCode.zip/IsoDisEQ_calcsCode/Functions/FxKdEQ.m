function [Ci] = FxKdEQ(WRo_Fx, Kds, TEi_BulkRock)
%function [Ci] = FxKdEQ(WRo_Fx, Kds, TEi_BulkRock)
%   Given the mass fraction of each phase in a BULK rock, partition coefficients
%   for each phase, and the initial concentration of a TE in the BULK rock,
%   calculates the concentration of that TE in each phase in the rock.

IdxN = isnan(WRo_Fx);
WRo_Fx(IdxN) = [];
Kds(IdxN) = [];

l = length(WRo_Fx);
Ci = zeros(1, l);

if l == 8
    for j = 1:l
        Ci(j) = TEi_BulkRock ./ ((WRo_Fx(1) .* ((Kds(1) ./ Kds(j)))) + (WRo_Fx(2) .* ((Kds(2) ./ Kds(j))))...
        + (WRo_Fx(3) .* ((Kds(3) ./ Kds(j)))) + (WRo_Fx(4) .* ((Kds(4) ./ Kds(j)))) + ...
        (WRo_Fx(5) .* ((Kds(5) ./ Kds(j)))) + (WRo_Fx(6) .* ((Kds(6) ./ Kds(j)))) + ...
        (WRo_Fx(7) .* ((Kds(7) ./ Kds(j)))) + (WRo_Fx(8) .* ((Kds(8) / Kds(j)))));
    end
elseif l == 9
    for j = 1:l
        Ci(j) = TEi_BulkRock ./ ((WRo_Fx(1) .* ((Kds(1) ./ Kds(j)))) + (WRo_Fx(2) .* ((Kds(2) ./ Kds(j))))...
        + (WRo_Fx(3) .* ((Kds(3) ./ Kds(j)))) + (WRo_Fx(4) .* ((Kds(4) ./ Kds(j)))) + ...
        (WRo_Fx(5) .* ((Kds(5) ./ Kds(j)))) + (WRo_Fx(6) .* ((Kds(6) ./ Kds(j)))) + ...
        (WRo_Fx(7) .* ((Kds(7) ./ Kds(j)))) + (WRo_Fx(8) .* ((Kds(8) ./ Kds(j)))) + ...
        (WRo_Fx(9) .* ((Kds(9) ./ Kds(j)))));
    end
else
end

end

