function [cTE_WR3, m_WR3] = cWR_E13calc(WR_Phz, TE_WRi, Liq2, cTE_Liq2, cP1TE, cP2TE, cP3TE)
%function [cTE_WR3, m_WR3] = cWR_E13calc(WR_Phz, TE_WRi, Liq2, cTE_Liq2, cP1TE, cP2TE, cP3TE)
%   see Eqns. 12 & 13 in Appendix E (isotopic diseq AFC). Calculates new BULK WR TE composition by mass closure.

if nargin == 6
    
    WR_Phz(1:2,:) = 0;
    
    for j = 1:length(WR_Phz)
        if WR_Phz(j,1) == 0
            TE_WRi(j,:) = 0;
        else
        end
        if WR_Phz(j,2) == 0
            cP1TE(j,:) = 0;
        else
        end
        if WR_Phz(j,3) == 0
            cP2TE(j,:) = 0;
        else
        end
    end

    WRi = sum(WR_Phz(:,1) .* TE_WRi);
    Per1 = sum(WR_Phz(:,2) .* cP1TE);
    Per2 = sum(WR_Phz(:,3) .* cP2TE);

    LiQ2 = Liq2(2) .* cTE_Liq2;

    m_WR3 = sum(WR_Phz(2:end,:));
    m_WR3 = sum(m_WR3, 2) + Liq2(2);

    num = WRi + Per1 + Per2 + LiQ2;

    cTE_WR3 = num ./ m_WR3;


elseif nargin > 6
    
    WR_Phz(1:2,:) = 0;
    
    for j = 1:length(WR_Phz)
        if WR_Phz(j,1) == 0
            TE_WRi(j,:) = 0;
        else
        end
        if WR_Phz(j,2) == 0
            cP1TE(j,:) = 0;
        else
        end
        if WR_Phz(j,3) == 0
            cP2TE(j,:) = 0;
        else
        end
        if WR_Phz(j,4) == 0
            cP3TE(j,:) = 0;
        else
        end
    end
        
    WRi = sum(WR_Phz(:,1) .* TE_WRi);
    Per1 = sum(WR_Phz(:,2) .* cP1TE);
    Per2 = sum(WR_Phz(:,3) .* cP2TE);
    Per3 = sum(WR_Phz(:,4) .* cP3TE);
   
    LiQ2 = Liq2(2) .* cTE_Liq2;

    m_WR3 = sum(WR_Phz(2:end,:));
    m_WR3 = sum(m_WR3, 2) + Liq2(2);

    num = WRi + Per1 + Per2 + Per3 + LiQ2;

    cTE_WR3 = num ./ m_WR3;
   
end
    
    




end

