function [m_Mnew, c_Mnew] = cM_E9calc(El, Mrow, Mdata, mLiq, cLiq)
%[m_Mnew, c_Mnew] = cM_E9calc(Mrow, Mdata, mLiq, cLiq)
%   Uses Eqn9 in Appdx E (Isotopic disequilibrium Appendix for Chaos
%   Crags Chp) to calculate  cTE & IsoRat in the new M subsystem AFTER AFC in MCS |
%   "t" variables refer to individual terms in the Eqn.

m_Mi = Mdata(Mrow,4);
mLiq = mLiq(1);
m_Mnew = m_Mi + mLiq;

if El == 'Ba'
    col = 23;
elseif El == 'Nd'
    col = 24;
elseif El == 'Rb'
    col = 25;
elseif El == 'Sm'
    col = 26;
elseif El == 'Sr'
    col = 27;
else
end

cM = Mdata(Mrow,col);
t2 = m_Mi / m_Mnew;


n = cM .* (m_Mi ./ m_Mnew);
d = cLiq .* (mLiq ./ m_Mnew);

c_Mnew = n + d;

end

