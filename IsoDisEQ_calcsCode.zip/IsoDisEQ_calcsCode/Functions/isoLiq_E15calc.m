function [isoTE_Liq2] = isoLiq_E15calc(Phz_Liq, TE_WRi, Iso_WRi, cP1TE, Liq1, c_TELiq1, IsoLiq1, Per2, Liq2, Kdp2, c_TELiq2)
%function [cTE_WR2, m_WR2] = cWR_E13calc(WR_Phz, TE_WRi, cP1TE, cP2TE, Liq2, cTE_Liq2)
%   see Eqns. 12 & 13 in Appendix E (isotopic diseq AFC). Calculates new
%   BULK WR TE composition by mass closure.

Phz_Liq = abs(Phz_Liq);

WRi_go = sum(Phz_Liq(:,1) .* TE_WRi .* Iso_WRi);
Per1_go = sum(Phz_Liq(:,2) .* cP1TE .* IsoLiq1);
Liq1_go = Liq1(2) .* c_TELiq1 .* IsoLiq1;


for i = 3:length(Per2)
    if Per2(i,1) > 0
        KdP2(i,1) = Kdp2(i,1);
    elseif Per2(i,1) == 0
        KdP2(i,1) = 0;
    end
end

m_Liq2 = sum(Liq2);
mKd_Per2 = sum(Per2 .* KdP2);

n = WRi_go + Per1_go + Liq1_go;
d = (m_Liq2 + mKd_Per2) .* c_TELiq2;

isoTE_Liq2 = n ./ d;


end
