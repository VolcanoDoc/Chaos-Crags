function [Iso_Mnew] = IsoMnew_E10calc(El, Mrow, Mdata, mLiq, cLiq, IsoLiq, cMnew)
%[m_Mnew, c_Mnew] = cM_E9calc(Mrow, Mdata, mLiq, cLiq)
%   Uses Eqn9 in Appdx E (Isotopic disequilibrium Appendix for Chaos
%   Crags Chp) to calculate  cTE & IsoRat in the new M subsystem AFTER AFC in MCS |
%   "t" variables refer to individual terms in the Eqn.

m_Mi = Mdata(Mrow,4);
mLiq = mLiq(1);
m_Mnew = m_Mi + mLiq;

if El == 'Nd'
    col = 24;
    RatCol = 28;
elseif El == 'Sr'
    col = 27;
    RatCol = 29; 
else
end

cM = Mdata(Mrow,col);

t1 = Mdata(Mrow,RatCol) .* Mdata(Mrow,col) .* m_Mi;
t2 = IsoLiq .* cLiq .* mLiq;
t3 = m_Mnew .* cMnew;


Iso_Mnew = (t1 + t2) ./ t3;

end

