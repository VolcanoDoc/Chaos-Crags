function [TERatios_phase, IsoRatios_Now] = IsoPhaseCalc(Initial_IsoRatio, Conc_parent, Conc_daughter, Age, lambda, IsoSys)
%function [TERatios_phase, IsoRatios_Now] = IsoPhaseCalc(Initial_IsoRatio, Conc_parent, Conc_daughter, Age, lambda)
%   Uses Eq. 5.9 in Faure & Mensing to calculate the isotopic composition
%   of an individual phase in a magma & also outputs the TE ratio used to
%   calculate that isotopic composition

[rows, cols] = size(Conc_parent);

TERatios_phase = Conc_parent ./ Conc_daughter;              

Initial_IsoRats = zeros(rows, cols);
for i = 1:rows
    Initial_IsoRats(i, cols) = Initial_IsoRatio;
end

Ages = zeros(rows, cols);
for i = 1:rows
    Ages(i, cols) = Age;
end

Lambdas = zeros(rows, cols);
for i = 1:rows
    Lambdas(i, cols) = lambda;
end

if IsoSys == 'Sr'
    corr = 2.89;
elseif IsoSys == 'Nd'
    corr = 0.602;
else
end


IsoRatios_Now = Initial_IsoRats + (corr .* TERatios_phase .* Lambdas .* Ages);


end

