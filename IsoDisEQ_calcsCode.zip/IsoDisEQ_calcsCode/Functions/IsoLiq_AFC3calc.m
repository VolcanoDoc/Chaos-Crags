function [Iso_LiqGen] = IsoLiq_AFC3calc(Phz_Liq, TE_WRi, Iso_WRi, m_LiqPeri, c_TELiqPeri, Iso_LiqPeri, PeriGen, LiqGen, cTE_LiqGen, KdPeri, TE_Peri1go, Iso_Perigo1, TE_Peri2go, Iso_Perigo2)
%function [Iso_LiqGen] = IsoLiq_AFC3calc(Phz_Liq, TE_WRi, Iso_WRi, m_LiqPeri, c_TELiqPeri, Iso_LiqPeri, PeriGen, LiqGen, cTE_LiqGen, KdPeri, TE_Peri1go, Iso_Peri1go, TE_Peri2go, Iso_Peri2go)
%   see Eqns. 12 & 13 in Appendix E (isotopic diseq AFC). TE concs of all phases involved in anatexis reactions are calculated to output TE
%   concentration of NEW melt & newly grown peritectic phases

Phz_Liq = abs(Phz_Liq);
Iso_Peri1go = zeros(16,17);
Iso_Peri2go = zeros(16,17);


%if nargin = 10, then NO peritectic phases contribute to the melt
if nargin == 10
  
    for j = 1:length(Phz_Liq)
        if Phz_Liq(j,1) == 0
            TE_WRi(j,:) = 0;
            Iso_WRi(j,:) = 0;
        else
        end
    end

    WRi_go = sum(Phz_Liq(:,1) .* TE_WRi .* Iso_WRi);
    LiqPeri = m_LiqPeri(2) .* c_TELiqPeri .* Iso_LiqPeri;

    for i = 3:length(PeriGen)
        if PeriGen(i,1) > 0
            KdPeri(i,1) = KdPeri(i,1);
        elseif PeriGen(i,1) == 0
            KdPeri(i,1) = 0;
        end
    end

    m_LiqGen = sum(LiqGen);
    mKd_Peri = sum(PeriGen .* KdPeri);

    n = WRi_go + LiqPeri;
    d = (m_LiqGen + mKd_Peri) .* cTE_LiqGen;    
    
    Iso_LiqGen = n ./ d;
    

%when nargin = 12, one peritectic phase contributes to the melt
elseif nargin == 12
    
    for i = 1:size(TE_WRi,2)
        Iso_Peri1go(:,i) = Iso_Perigo1(i);
    end
    
    for j = 1:length(Phz_Liq)
        if Phz_Liq(j,1) == 0
            TE_WRi(j,:) = 0;
            Iso_WRi(j,:) = 0;
        else
        end
        
        if Phz_Liq(j,2) == 0
            TE_Peri1go(j,:) = 0;
            Iso_Peri1go(j,:) = 0;
        else
        end
    end

    WRi_go = sum(Phz_Liq(:,1) .* TE_WRi .* Iso_WRi);
    LiqPeri = m_LiqPeri(2) .* c_TELiqPeri .* Iso_LiqPeri;
    Peri1_go = sum(Phz_Liq(:,2) .* TE_Peri1go .* Iso_Peri1go);

    for i = 3:length(PeriGen)
        if PeriGen(i,1) > 0
            KdPeri(i,1) = KdPeri(i,1);
        elseif PeriGen(i,1) == 0
            KdPeri(i,1) = 0;
        end
    end

    m_LiqGen = sum(LiqGen);
    mKd_Peri = sum(PeriGen .* KdPeri);

    n = WRi_go + LiqPeri + Peri1_go;
    d = (m_LiqGen + mKd_Peri) .* cTE_LiqGen; 
    
    Iso_LiqGen = n ./ d;
    
    
%when nargin = 14, two peritectic phases contribute to the melt
elseif nargin == 14
 
    for i = 1:size(TE_WRi,2)
        Iso_Peri1go(:,i) = Iso_Perigo1(i);
        Iso_Peri2go(:,i) = Iso_Perigo2(i);
    end
    
    for j = 1:length(Phz_Liq)
        if Phz_Liq(j,1) == 0
            TE_WRi(j,:) = 0;
            Iso_WRi(j,:) = 0;
        else
        end
        if Phz_Liq(j,2) == 0
            TE_Peri1go(j,:) = 0;
            Iso_Peri1go(j,:) = 0;
        else
        end
        if Phz_Liq(j,3) == 0
            TE_Peri2go(j,:) = 0;
            Iso_Peri2go(j,:) = 0;
        else
        end
    end

    WRi_go = sum(Phz_Liq(:,1) .* TE_WRi .* Iso_WRi);
    LiqPeri = m_LiqPeri(2) .* c_TELiqPeri .* Iso_LiqPeri;
    Peri1_go = sum(Phz_Liq(:,2) .* TE_Peri1go .* Iso_Peri1go);
    Peri2_go = sum(Phz_Liq(:,3) .* TE_Peri2go .* Iso_Peri2go);

    for i = 3:length(PeriGen)
        if PeriGen(i,1) > 0
            KdPeri(i,1) = KdPeri(i,1);
        elseif PeriGen(i,1) == 0
            KdPeri(i,1) = 0;
        end
    end

    m_LiqGen = sum(LiqGen);
    mKd_Peri = sum(PeriGen .* KdPeri);

    n = WRi_go + LiqPeri + Peri1_go;
    d = (m_LiqGen + mKd_Peri) .* cTE_LiqGen; 
    
    Iso_LiqGen = n ./ d;
    



end

