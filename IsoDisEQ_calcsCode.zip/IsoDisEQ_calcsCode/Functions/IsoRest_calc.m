function [IsoRst] = IsoRest_calc(m_Rst, cRst, isoRst)
%function [IsoRst] = IsoRest_calc(m_Rst, cRst, isoRst)
%   Uses Eqn. ? in Appdx E (Isotopic disequilibrium Appendix for Chaos
%   Crags Chp) to calculate isotopic signature of restite AFTER AFC step

mBulk = sum(m_Rst);
t1 = sum(m_Rst .* cRst);

cBulk = t1 ./ mBulk;

t2 = m_Rst / mBulk;
t3 = cRst / cBulk;

IndivPhz = isoRst .* t2 .* t3;
IsoRst = sum(IndivPhz);



end

