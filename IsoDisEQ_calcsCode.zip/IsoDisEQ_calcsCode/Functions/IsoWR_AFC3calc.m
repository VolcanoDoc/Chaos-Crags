function [IsoTE_WR3] = IsoWR_AFC3calc(WR_Phz, TE_WRi, Iso_WRi, Liq, cTE_Liq, Iso_Liq, cP1TE, IsoPeri1, cP2TE, IsoPeri2, cP3TE, IsoPeri3, cTE_WR3)
%function [cTE_WR3, m_WR3] = cWR_E13calc(WR_Phz, TE_WRi, Liq2, cTE_Liq2, cP1TE, cP2TE, cP3TE)
%   see Eqns. 12 & 13 in Appendix E (isotopic diseq AFC). Calculates new BULK WR TE composition by mass closure.


    
    WR_Phz(1:2,:) = 0;
    Iso_Peri1 = zeros(16,17);
    Iso_Peri2 = zeros(16,17);
    Iso_Peri3 = zeros(16,17);

    for i = 1:size(TE_WRi,2)
        Iso_Peri1(:,i) = IsoPeri1(i);
        Iso_Peri2(:,i) = IsoPeri2(i);
        Iso_Peri3(:,i) = IsoPeri3(i);
    end
    
    for j = 1:length(WR_Phz)
        if WR_Phz(j,1) == 0
            TE_WRi(j,:) = 0;
            Iso_WRi(j,:) = 0;
        else
        end
        if WR_Phz(j,2) == 0
            cP1TE(j,:) = 0;
            Iso_Peri1(j,:) = 0;
        else
        end
        if WR_Phz(j,3) == 0
            cP2TE(j,:) = 0;
            Iso_Peri2(j,:) = 0;
        else
        end
        if WR_Phz(j,4) == 0
            cP3TE(j,:) = 0;
            Iso_Peri3(j,:) = 0;
        else
        end
    end

    WRi = sum(WR_Phz(:,1) .* TE_WRi .* Iso_WRi);
    Per1 = sum(WR_Phz(:,2) .* cP1TE .* Iso_Peri1);
    Per2 = sum(WR_Phz(:,3) .* cP2TE .* Iso_Peri2);
    Per3 = sum(WR_Phz(:,4) .* cP3TE .* Iso_Peri3);

    LiQ2 = Liq(2) .* cTE_Liq .* Iso_Liq;

    m_WR3 = sum(WR_Phz(2:end,:));
    m_WR3 = sum(m_WR3, 2) + Liq(2);

    num = WRi + Per1 + Per2 + Per3 + LiQ2;
    denom = m_WR3 .* cTE_WR3;

    IsoTE_WR3 = num ./ denom;





end

