function [iso_Mnew] = IsoM_postAFC(mMagma, cMagma, isoMagma, mLiq, cLiq, isoLiq, c_Mnew)
%[m_Mnew, c_Mnew] = cM_E9calc(Mrow, Mdata, mLiq, cLiq)
%   Uses Eqn9 in Appdx E (Isotopic disequilibrium Appendix for Chaos
%   Crags Chp) to calculate cTE & new mass AFTER 2+ AFC increments (made
%   different function bc using calculated values instead of sourcing from
%   MCS input file).


mLiq = mLiq(1);
m_Mnew = mMagma + mLiq;


t1 = cMagma .* mMagma .* isoMagma;
t2 = cLiq .* mLiq .* isoLiq;
t3 = m_Mnew .* c_Mnew;


iso_Mnew = (t1 + t2) ./ t3;

end

