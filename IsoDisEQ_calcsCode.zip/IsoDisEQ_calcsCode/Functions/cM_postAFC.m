function [m_Mnew, c_Mnew] = cM_postAFC(mMagma, cMagma, mLiq, cLiq)
%[m_Mnew, c_Mnew] = cM_E9calc(Mrow, Mdata, mLiq, cLiq)
%   Uses Eqn9 in Appdx E (Isotopic disequilibrium Appendix for Chaos
%   Crags Chp) to calculate cTE & new mass AFTER 2+ AFC increments (made
%   different function bc using calculated values instead of sourcing from
%   MCS input file).




mLiq = mLiq(1);
m_Mnew = mMagma + mLiq;


n = cMagma .* (mMagma ./ m_Mnew);
d = cLiq .* (mLiq ./ m_Mnew);


c_Mnew = n + d;

end

