function [cTE_LiqGen, cTE_PeriGen] = cLiq_AFC3calc(Phz_Liq, TE_WRi, m_LiqPeri, c_TELiqPeri, PeriGen, LiqGen, KdPeri, TE_Perigo1, TE_Perigo2)
%function [cTE_Liq3, cTE_Per3] = cLiq_AFC3calc(Phz_Liq, TE_WRi, cP1TE, m_LiqPeri, c_TELiq, PeriGen, LiqGen, KdPeri, TE_Perigo1, TE_Perigo2)
%   see Eqns. 12 & 13 in Appendix E (isotopic diseq AFC). TE concs of all
%   phases involved in anatexis reactions are calculated to output TE
%   concentration of NEW melt & newly grown peritectic phases

Phz_Liq = abs(Phz_Liq);

%if nargin = 7, then NO peritectic phases contribute to the melt
if nargin == 7
  
    for j = 1:length(Phz_Liq)
        if Phz_Liq(j,1) == 0
            TE_WRi(j,:) = 0;
        else
        end
    end

    WRi_go = sum(Phz_Liq(:,1) .* TE_WRi);
    LiqPeri_go = m_LiqPeri(2) .* c_TELiqPeri;

    for i = 3:length(PeriGen)
        if PeriGen(i,1) > 0
            KdPeri(i,1) = KdPeri(i,1);
        elseif PeriGen(i,1) == 0
            KdPeri(i,1) = 0;
        end
    end

    m_LiqGen = sum(LiqGen);
    mKd_Peri = sum(PeriGen .* KdPeri);

    n = WRi_go + LiqPeri_go;
    d = m_LiqGen + mKd_Peri;    
    
    cTE_LiqGen = n ./ d;
    cTE_PeriGen = KdPeri .* cTE_LiqGen;

%when nargin = 8, one peritectic phase contributes to the melt
elseif nargin == 8
  
    for j = 1:length(Phz_Liq)
        if Phz_Liq(j,1) == 0
            TE_WRi(j,:) = 0;
        else
        end
        if Phz_Liq(j,2) == 0
            TE_Perigo1(j,:) = 0;
        else
        end
    end

    WRi_go = sum(Phz_Liq(:,1) .* TE_WRi);
    LiqPeri_go = m_LiqPeri(2) .* c_TELiqPeri;
    Peri1_go = sum(Phz_Liq(:,2) .* TE_Perigo1);

    for i = 3:length(PeriGen)
        if PeriGen(i,1) > 0
            KdPeri(i,1) = KdPeri(i,1);
        elseif PeriGen(i,1) == 0
            KdPeri(i,1) = 0;
        end
    end

    m_LiqGen = sum(LiqGen);
    mKd_Peri = sum(PeriGen .* KdPeri);

    n = WRi_go + LiqPeri_go + Peri1_go;
    d = m_LiqGen + mKd_Peri;    
    
    cTE_LiqGen = n ./ d;
    cTE_PeriGen = KdPeri .* cTE_LiqGen;
    
%when nargin = 9, two peritectic phases contribute to the melt
elseif nargin == 9
  
    for j = 1:length(Phz_Liq)
        if Phz_Liq(j,1) == 0
            TE_WRi(j,:) = 0;
        else
        end
        if Phz_Liq(j,2) == 0
            TE_Perigo1(j,:) = 0;
        else
        end
        if Phz_Liq(j,3) == 0
            TE_Perigo2(j,:) = 0;
        else
        end
    end

    WRi_go = sum(Phz_Liq(:,1) .* TE_WRi);
    LiqPeri_go = m_LiqPeri(2) .* c_TELiqPeri;
    Peri1_go = sum(Phz_Liq(:,2) .* TE_Perigo1);
    Peri2_go = sum(Phz_Liq(:,3) .* TE_Perigo2);

    for i = 3:length(PeriGen)
        if PeriGen(i,1) > 0
            KdPeri(i,1) = KdPeri(i,1);
        elseif PeriGen(i,1) == 0
            KdPeri(i,1) = 0;
        end
    end

    m_LiqGen = sum(LiqGen);
    mKd_Peri = sum(PeriGen .* KdPeri);

    n = WRi_go + LiqPeri_go + Peri1_go + Peri2_go;
    d = m_LiqGen + mKd_Peri;    
    
    cTE_LiqGen = n ./ d;
    cTE_PeriGen = KdPeri .* cTE_LiqGen;



end

