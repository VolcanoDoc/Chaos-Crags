function [cTE_Mnew, m_Mfc] = Mfxn_Calc(KdTE, cTEi_M, FxdMins, m_Mall, FCrow)
%function [cTE_Mnew] = Mfxn_Calc(KdTE, cTEi_M, FxdMins, Liq, FCrow)
%   Given starting conditions of a magma M that fractionates some mass of
%   xls, this function calculates the new TE composition of M AFTER
%   fractionation has occurred

rows = size(KdTE,2);
cols = size(cTEi_M,2);
cTEmins = zeros(rows, cols);

%below code calculates TE concentrations for fractionating phases
for i=1:rows
    cTEmins(i,:) = cTEi_M .* KdTE(:,i);
end

%below code calculates the masses of fractionating xls & the new M subsystem
fxXls = FxdMins(FCrow,:)';
m_Xls = sum(fxXls);
m_Mfc = m_Mall - m_Xls;


t1 = m_Mall / m_Mfc;
for i = 1:cols
    t2(:,i) = (fxXls / m_Mfc) .* cTEmins(:,i);
end


cTE_Mnew = (cTEi_M .* t1) - sum(t2);


end

