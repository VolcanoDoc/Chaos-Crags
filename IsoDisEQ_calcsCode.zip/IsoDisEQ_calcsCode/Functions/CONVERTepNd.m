function [epNd] = CONVERTepNd(isoNd)
%function [epNd] = CONVERTepNd(isoNd)
%   converts measured 143/144Nd isotopic values into epNd values

epNd = ((isoNd - 0.512638) ./ 0.512638) .* 10000;    %MEASURED isoNd from the LITERATURE

end

