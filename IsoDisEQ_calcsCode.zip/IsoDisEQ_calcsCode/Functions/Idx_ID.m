function [Idx2] = Idx_ID(SearchRowORCol, X)
%function [Idx2] = Idx_ID(SearchRowORCol, X)
%   General function to search inputarg 'SearchRowORCol'for a string of characters 'X', 
%   and returns the indices within inputRoworCol where X is located.


Idx1 = contains(SearchRowORCol, X);                                    %searches through the string array to find 'AFC'
Idx2 = find(Idx1);                                                     %returns the index for IDX1




end

