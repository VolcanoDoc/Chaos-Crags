function [isoWR2] = isoWR_calc(WR_Phz, TE_WRi, isoWRi, cP1TE, isoLiq1, cP2TE, Liq2, cTE_Liq2, isoLiq2, cTE_WR2)
%function [cTE_WR2, m_WR2] = cWR_E13calc(WR_Phz, TE_WRi, cP1TE, cP2TE, Liq2, cTE_Liq2)
%   see Eqns. 12 & 13 in Appendix E (isotopic diseq AFC). Calculates new
%   BULK WR TE composition by mass closure.

%n_t1 = WR_Phz(:,1) .* TE_WRi .* isoWRi
%n_t2 = WR_Phz(:,2) .* cP1TE .* isoLiq1
WR_Phz(1:2,3) = 0;
%n_t3 = WR_Phz(:,3) .* cP2TE .* isoLiq2



WRi = sum(WR_Phz(:,1) .* TE_WRi .* isoWRi);
Per1 = sum(WR_Phz(:,2) .* cP1TE .* isoLiq1);

Per2 = sum(WR_Phz(:,3) .* cP2TE .* isoLiq2);
liq2 = Liq2(2) .* cTE_Liq2 .* isoLiq2;

m_WR2 = sum(WR_Phz,2);
m_WR2 = sum(m_WR2) + Liq2(2);

num = WRi + Per1 + Per2 + liq2;
d = m_WR2 .* cTE_WR2;

isoWR2 = num ./ d;

end

