function [cTE_Liq2, cTE_Per2] = cLiq_E12calc(Phz_Liq, TE_WRi, cP1TE, Liq1, c_TELiq1, Per2, Liq2, Kdp2)
%function [cTE_Liq2, cTE_Per2] = cLiq_E12calc(Phz_Liq, TE_WRi, cP1TE, Liq1, c_TELiq1, Per2, Liq2, Kdp2)
%   see Eqns. 12 & 13 in Appendix E (isotopic diseq AFC). TE concs of all
%   phases involved in anatexis reactions are calculated to output TE
%   concentration of NEW melt & newly grown peritectic phases

Phz_Liq = abs(Phz_Liq);

for j = 1:length(Phz_Liq)
    if Phz_Liq(j,1) == 0
        TE_WRi(j,:) = 0;
    else
    end
    if Phz_Liq(j,2) == 0
        cP1TE(j,:) = 0;
    else
    end
end
        

WRi_go = sum(Phz_Liq(:,1) .* TE_WRi);
Per1_go = sum(Phz_Liq(:,2) .* cP1TE);
Liq1_go = Liq1(2) .* c_TELiq1;


for i = 3:length(Per2)
    if Per2(i,1) > 0
        KdP2(i,1) = Kdp2(i,1);
    elseif Per2(i,1) == 0
        KdP2(i,1) = 0;
    end
end

m_Liq2 = sum(Liq2);
mKd_Per2 = sum(Per2 .* KdP2);

n = WRi_go + Per1_go + Liq1_go;
d = m_Liq2 + mKd_Per2;

cTE_Liq2 = n ./ d;
cTE_Per2 = KdP2 .* cTE_Liq2;




end

