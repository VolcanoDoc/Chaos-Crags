clear;
clc;                                                   %adds folder containing functions to pathway
format long
tic;

addpath('Data')                                                             %adds folder containing data files to pathway
addpath('Functions')     

%% Load in MCS Output Data

InPuT1 = 0;
while InPuT1 ~= 1
    AFCBase = input('What Base AFC Model is used? \n','s');
    if strcmp(AFCBase, '21SepF')  
        [MCS_TEOut] = importdata('MCS_IsoDisEq_AFC_21SepF.xlsx');            %uses importdata to read Excel file of MCS Output Data
        InPuT1 = 1;
    elseif strcmp(AFCBase, '22SepB')
        [MCS_TEOut] = importdata('MCS_IsoDisEq_AFC_22SepB.xlsx');            %uses importdata to read Excel file of MCS Output Data
        InPuT1 = 1;
    elseif strcmp(AFCBase, '22SepA')
        [MCS_TEOut] = importdata('MCS_IsoDisEq_AFC_22SepA.xlsx');            %uses importdata to read Excel file of MCS Output Data
        InPuT1 = 1;
    else
        error('You have selected an AFC Model not coded in!!!')
    end  
end

[Kds] = importdata('Kds_Felsic.xlsx');
[WRpossibles] = importdata('SNG_LitCompos.xlsx');                                  %uses importdata to read Excel file of WR compositions
%Note: Initial 87Sr/86Sr and ages for Cecil samples G05 & G12, and ALL 
%Borg & Clynne WR samples were randomly selected from a uniform distribution 
%along the interval of the min & max (excluding the outlier value)

KdsBa1 = (Kds.data(1,:))';
KdsNd1 = (Kds.data(2,:))';
KdsRb1 = (Kds.data(3,:))';
KdsSm1 = (Kds.data(4,:))';
KdsSr1 = (Kds.data(5,:))';

nWR = size(WRpossibles.data, 1);


%% Identifying AFC Onset & WR Geochron Parameters

Process = MCS_TEOut.textdata(:,2);
Idx1 = Idx_ID(Process, 'AFC');                                  %uses Idx_ID to ID row of AFC onset
RowAFC_Onset = Idx1(1) - 1;                                     %offset by 1 b/c of titles in .textdata
RowWR_Orig = RowAFC_Onset - 1;

lamSr = 1.42e-11;                                               %lambda for Rb-Sr isotope system
lamNd = 6.54e-12;                                               %lambda for Sm-Nd isotope system
WRSrIsoi = WRpossibles.data(:,25);                              %initial Iso Ratio of WR
WRNdIsoi = WRpossibles.data(:,24);                          

WRage = WRpossibles.data(:,26);                                 %ages of WR
a1 = max(WRpossibles.data(1:11,26));                            %max of Cecil ages
a2 = min(WRpossibles.data(1:11,26));                            %min of Cecil ages

%the below line of code generates a random sampling from a uniform distribution of ages within the range of Cecil samples
%a3 = a2 + (a1 - a2) .* rand(6,1);                               
%the below lines of code replace the skewed ages (picked by FJS - see lab notebook 25Feb2020 for more) with a random sampling generated on 25Feb2020, then a3
%variable deactivated to preserve those chosen values & replaced in WRage as a vector:
%WRage(12:end, 1) = a3
%WRage(12:end, 1) = [291739928; 192397163; 358908399; 118059319; 224389767; 209349874]

LitWRisoNd = WRpossibles.data(:,23);                            %MEASURED isoNd from the LITERATURE
LitWRepNd = CONVERTepNd(LitWRisoNd);                            %uses 'convert epNd function to generate epNd values)
LitWRisoSr = WRpossibles.data(:,22);                            %MEASURED isoSr from the LITERATURE          

Rb_WRbulk = WRpossibles.data(:,20)';                            %MEASURED TE concentrations from the LITERATURE
Sr_WRbulk = WRpossibles.data(:,17)';                                      
Sm_WRbulk = WRpossibles.data(:,21)';
Nd_WRbulk = WRpossibles.data(:,18)';
Ba_WRbulk = WRpossibles.data(:,19)';

%below code REPLACES the reported initial 87/86Sr for the bulk rock w/ new values calculated by Eqn. 5.9 of Faure & Mensing (2001) - Cecil et al.
%(2012) notes potential metasedimentary WR or seawater contamination leading to some of the highest 87/86Sri values
WRSrIsoi = LitWRisoSr - (2.89 .* (Rb_WRbulk' ./ Sr_WRbulk') .* lamSr .* WRage);

%below code REPLACES the reported initial 143/144Nd for the bulk rock w/ new values calculated by Eqn. 9.5 of Faure & Mensing (2001)
WRNdIsoi = LitWRisoNd - (0.602 .* (Sm_WRbulk' ./ Nd_WRbulk') .* lamNd .* WRage);

%% Calculate Mineral Proportions in INITIAL bulk rock & their TE Concentrations

WRo_X = (MCS_TEOut.data(RowWR_Orig, 7:22))';                     %sets WRo composition
WRo_m = sum(WRo_X);
WRo_X(WRo_X == 0) = NaN;

WRo_Fx = WRo_X ./ WRo_m;                                        %calculates proportion of each phase in the WR
WRo_Fx(1:2) = [];                                               %removes top 2 elements (melt=0) of vector


Idx1 = Idx_ID(Process, 'AFC');                                  %uses Idx_ID to ID row of AFC onset

%below code identifies phases NOT present in WR & changes Kd values to NaN (FxKdEQ function removes extra phases)
IdxN = isnan(WRo_Fx);
KdsBa = KdsBa1;
KdsNd = KdsNd1;
KdsRb = KdsRb1;
KdsSm = KdsSm1;
KdsSr = KdsSr1;

KdsBa(IdxN) = NaN;
KdsNd(IdxN) = NaN;
KdsRb(IdxN) = NaN;
KdsSm(IdxN) = NaN;
KdsSr(IdxN) = NaN;


for jj = 1:nWR
    [Bai_Mins(:,jj)] = FxKdEQ(WRo_Fx, KdsBa, Ba_WRbulk(jj));     %calculates initial Rb conc. for each WR phase
    [Ndi_Mins(:,jj)] = FxKdEQ(WRo_Fx, KdsNd, Nd_WRbulk(jj));     %calculates initial Sr conc. for each WR phase
    [Rbi_Mins(:,jj)] = FxKdEQ(WRo_Fx, KdsRb, Rb_WRbulk(jj));     %calculates initial Rb conc. for each WR phase
    [Smi_Mins(:,jj)] = FxKdEQ(WRo_Fx, KdsSm, Sm_WRbulk(jj));     %calculates initial Rb conc. for each WR phase
    [Sri_Mins(:,jj)] = FxKdEQ(WRo_Fx, KdsSr, Sr_WRbulk(jj));     %calculates initial Rb conc. for each WR phase
end


%% Calculate INITIAL Isotope Ratio for each phase in bulk rock

nMin = size(Bai_Mins,1);
IsoSr_WRall = zeros(nMin, nWR);                                            
TERats_WRall = zeros(nMin, nWR);
BulkCalc = zeros(nMin,nWR);

%Below code uses IsoPhaseCalc function to calculate the 87Sr/86Sr for each phase in the WR mineral assemblage, for every WR considered.
for i = 1:nWR
    [RbSr_WRall(:,i), IsoSr_WRall(:,i)] = IsoPhaseCalc(WRSrIsoi(i), Rbi_Mins(:,i), Sri_Mins(:,i), WRage(i), lamSr, 'Sr');
    [SmNd_WRall(:,i), IsoNd_WRall(:,i)] = IsoPhaseCalc(WRNdIsoi(i), Smi_Mins(:,i), Ndi_Mins(:,i), WRage(i), lamNd, 'Nd');
end

%Below code calculates bulk 87/86Sr of WR (based on calculations, for comparison against measured values (should match if mass closure calculations done correctly)
WRo_Fx(IdxN) = [];
for i = 1:nWR
    IsoSr_Fx(:,i) = IsoSr_WRall(:,i) .* WRo_Fx .* (Sri_Mins(:,i) ./ Sr_WRbulk(i));
    IsoNd_Fx(:,i) = IsoNd_WRall(:,i) .* WRo_Fx .* (Ndi_Mins(:,i) ./ Nd_WRbulk(i));
    BaFx(:,i) = Bai_Mins(:,i) .* WRo_Fx;
    NdFx(:,i) = Ndi_Mins(:,i) .* WRo_Fx;
    RbFx(:,i) = Rbi_Mins(:,i) .* WRo_Fx;
    SmFx(:,i) = Smi_Mins(:,i) .* WRo_Fx;
    SrFx(:,i) = Sri_Mins(:,i) .* WRo_Fx;
end

%below code are new variables for bulk WR values (checking for isotopic closure)
IsoSr_WR = (sum(IsoSr_Fx))';
IsoNd_WR = (sum(IsoNd_Fx))';
BaNew = (sum(BaFx))';
NdNew = (sum(NdFx))';
RbNew = (sum(RbFx))';
SmNew = (sum(SmFx))';
SrNew = (sum(SrFx))';


%% Create Data Table outputs in EXCEL
Publication = WRpossibles.textdata(2:end,1);
Samp = WRpossibles.textdata(2:end,2);
LitMeasured_Rb = Rb_WRbulk';
LitMeasured_Sr = Sr_WRbulk';

if strcmp(AFCBase, '21SepF')
    Phases = {'bt'; 'cpx'; 'fl'; 'il'; 'kfs'; 'mt'; 'opx'; 'pl'; 'qtz'};
    WRcol = 16;
elseif strcmp(AFCBase, '22SepB')
    Phases = {'ap'; 'bt'; 'fl'; 'il'; 'kfs'; 'mt'; 'ol'; 'opx'; 'pl'};
    WRcol = 4;
elseif strcmp(AFCBase, '22SepA')
    Phases = {'gt'; 'il'; 'kfs'; 'leuc'; 'mt'; 'pl'; 'qtz'; 'sill'};
    WRcol = 5;
else
end

%below code creates a table w/ initial WR compositions & isotopic ratios 
T1 = table(Publication, Samp, BaNew, NdNew, RbNew, SmNew, SrNew, IsoSr_WR, IsoNd_WR, WRSrIsoi, WRNdIsoi, WRage);
T1.Properties.VariableNames = {'Publication', 'Sample_Name', 'Ba', 'Nd', 'Rb', 'Sm', 'Sr',...
    'Measured_8786Sr', 'Measured_143144Nd', 'Initial_IsoSr', 'Initial_IsoNd', 'Age'};


%below concatenates data to prepare it for T2 output
P_tbl = vertcat(Phases, 'bulk');
fX_tbl = vertcat(WRo_X, WRo_m);
IdxN2 = isnan(fX_tbl);
fX_tbl(IdxN2) = [];
Ba_tbl = vertcat(Bai_Mins, BaNew');
Nd_tbl = vertcat(Ndi_Mins, NdNew');
Rb_tbl = vertcat(Rbi_Mins, RbNew');
Sm_tbl = vertcat(Smi_Mins, SmNew');
Sr_tbl = vertcat(Sri_Mins, SrNew');
IsoSr_tbl = vertcat(IsoSr_WRall, IsoSr_WR');
IsoNd_tbl = vertcat(IsoNd_WRall, IsoNd_WR');
KdsBa(IdxN) = [];
KdBa_tbl = vertcat(KdsBa, NaN);
KdsNd(IdxN) = [];
KdNd_tbl = vertcat(KdsNd, NaN);
KdsRb(IdxN) = [];
KdRb_tbl = vertcat(KdsRb, NaN);
KdsSm(IdxN) = [];
KdSm_tbl = vertcat(KdsSm, NaN);
KdsSr(IdxN) = [];
KdSr_tbl = vertcat(KdsSr, NaN);
WRage_tbl = NaN(size(Sr_tbl));
WRage_tbl(end) = (WRage(WRcol) ./ 1e6);     %adjusted to display age in Ma instead of yrs

%below code creates Table E1 (INDIVIDUAL PHASES)
T2 = table(P_tbl, fX_tbl, KdRb_tbl, KdSr_tbl, KdSm_tbl, KdNd_tbl, Rb_tbl, Sr_tbl, Sm_tbl,...
    Nd_tbl, IsoSr_tbl, IsoNd_tbl, WRage_tbl);
T2.Properties.VariableNames = {'Phase', 'mass_g', 'Kd_Rb', 'Kd_Sr', 'Kd_Sm', 'Kd_Nd', 'Rb_ppm',...
    'Sr_ppm', 'Sm_ppm', 'Nd_ppm', 'IsoSr', 'IsoNd', 'Age'};


%% Export Tables of WR initial conditions to Excel files

%below code prompts user to choose whether or not to output data Excel table
InPuT1 = 0;
while InPuT1 ~= 1
    TblOut1 = input('Would you like to export Tables containing INITIAL WR conditions? \n','s');
    if strcmp(TblOut1, 'y') || strcmp(TblOut1, 'yes')   
        filename1 = 'SNGWR_InitialIsoConditions.xlsx';
        writetable(T1, filename1); 
        
    elseif strcmp(TblOut1, 'n') || strcmp(TblOut1, 'no')
        InPuT1 = 1;
    end  
end

clear *_tbl

%% AFC Step 1 - Changes to WR Subsystem

WRi = WRo_X;                                                    %Initial WR X BEFORE AFC onset
WRi(1:2) = 0;
WRi(isnan(WRi)) = 0;
nPhz = size(WRi,1);
Rst1 = (MCS_TEOut.data(RowAFC_Onset, 7:22))';                   %WR restite after AFC1
R1xls = {'liqM'; 'liqWR'; 'ap'; 'bt'; 'cpx'; 'fl'; 'gt'; 'il'; 'kfs'; 'leuc';...
    'mt'; 'ol'; 'opx'; 'pl'; 'qtz'; 'sill'};

%below code creates empty matrices to assign TE concentrations back into larger matrices
Ba_WRi = zeros(nPhz,nWR);                                
Nd_WRi = zeros(nPhz,nWR);
Rb_WRi = zeros(nPhz,nWR);
Sm_WRi = zeros(nPhz,nWR);
Sr_WRi = zeros(nPhz,nWR);
IsoSr_WRi = zeros(nPhz,nWR);
IsoNd_WRi =zeros(nPhz,nWR);

%below code appends two zero cells to top of Kd vectors so matrices will be same size for later calculations
KdsBa1 = vertcat(0, 0, KdsBa1);
KdsNd1 = vertcat(0, 0, KdsNd1);
KdsRb1 = vertcat(0, 0, KdsRb1);
KdsSm1 = vertcat(0, 0, KdsSm1);
KdsSr1 = vertcat(0, 0, KdsSr1);

%below for loop puts calculated initial TE contents & isotopic ratio of each PHASE back into the original 14-phase list (NaNs had to be removed to calculate isotopes
%correctly, but original configuration needs to be used for bookkeeping during AFC calculations
j = 1;
while j< 10
    for k = 3:16 
        if WRi(k) == 0
            j = j;
        elseif WRi(k,1) > 0
            Ba_WRi(k,:) = Bai_Mins(j,:);
            Nd_WRi(k,:) = Ndi_Mins(j,:);
            Rb_WRi(k,:) = Rbi_Mins(j,:);
            Sm_WRi(k,:) = Smi_Mins(j,:);
            Sr_WRi(k,:) = Sri_Mins(j,:);
            IsoSr_WRi(k,:) = T2.IsoSr(j,:);
            IsoNd_WRi(k,:) = T2.IsoNd(j,:);
            j = j+1;
        end
    end
    break
end

%below code identifies NEWLY GROWN peritectic phases
delWR1 = Rst1 - WRi;                                            %delWR1 = net rxn for each phase (growth or dissolution)
IdxP1 = delWR1 > 0;                                              %IdxP = location of peritectic SOLIDS (no melt included)  
Per1 = zeros(size(delWR1));
Liq1 = Per1;

%below for loop creates variables for unmelted WRi restite, newly-grown peritectic phases, & newly-generated melt
for kk = 3:size(IdxP1,1)
    if IdxP1(kk,1) == 1
        Per1(kk,1) = delWR1(kk,1);                              %Peri1 = mass of new peritectic growth
        Rst1(kk,1) = WRi(kk,1);
    else
    end
end
Liq1(1:2,1) = Rst1(1:2,1);                                      %Liq1 = mass of newly-generated melt
Rst1(1:2,1) = 0;  
m_Rst1 = sum(Rst1(3:end,1));                                    %m_Rst1 = mass of UNMELTED WRi "solids" 

%below code calculates the g of each TE in each indiv PHASE in the restite
g_BaWRi = Rst1 .* Ba_WRi;
g_NdWRi = Rst1 .* Nd_WRi;
g_RbWRi = Rst1 .* Rb_WRi;
g_SmWRi = Rst1 .* Sm_WRi;
g_SrWRi = Rst1 .* Sr_WRi;

%below code uses Kds to calculate the g of each TE in each newly grown PERITECTIC phase
g_BaP1 = Per1 .* KdsBa1;
g_NdP1 = Per1 .* KdsNd1;
g_RbP1 = Per1 .* KdsRb1;
g_SmP1 = Per1 .* KdsSm1;
g_SrP1 = Per1 .* KdsSr1;

%below code calculates new cTE for FIRST bit of melt produced by AFC
c_BaLq1 = cLiq_E5calc(Ba_WRbulk, g_BaWRi, g_BaP1, Liq1);
c_NdLq1 = cLiq_E5calc(Nd_WRbulk, g_NdWRi, g_NdP1, Liq1);
c_RbLq1 = cLiq_E5calc(Rb_WRbulk, g_RbWRi, g_RbP1, Liq1);
c_SmLq1 = cLiq_E5calc(Sm_WRbulk, g_SmWRi, g_SmP1, Liq1);
c_SrLq1 = cLiq_E5calc(Sr_WRbulk, g_SrWRi, g_SrP1, Liq1);

%below code calculates new cTE for bulk rock of WR1 subsystem (solids + liq)
[cWR1_Ba] = cWR_E3calc(Ba_WRbulk, sum(WRo_X, 'omitnan'), c_BaLq1, Liq1, m_Rst1, Per1);
[cWR1_Nd] = cWR_E3calc(Nd_WRbulk, sum(WRo_X, 'omitnan'), c_NdLq1, Liq1, m_Rst1, Per1);
[cWR1_Rb] = cWR_E3calc(Rb_WRbulk, sum(WRo_X, 'omitnan'), c_RbLq1, Liq1, m_Rst1, Per1);
[cWR1_Sm] = cWR_E3calc(Sm_WRbulk, sum(WRo_X, 'omitnan'), c_SmLq1, Liq1, m_Rst1, Per1);
[cWR1_Sr] = cWR_E3calc(Sr_WRbulk, sum(WRo_X, 'omitnan'), c_SrLq1, Liq1, m_Rst1, Per1);

%below code calculates new cTE for PERITECTIC phases
[cP1_Ba] = cPeriCalc(c_BaLq1, Per1, KdsBa1);
[cP1_Nd] = cPeriCalc(c_NdLq1, Per1, KdsNd1);
[cP1_Rb] = cPeriCalc(c_RbLq1, Per1, KdsRb1);
[cP1_Sm] = cPeriCalc(c_SmLq1, Per1, KdsSm1);
[cP1_Sr] = cPeriCalc(c_SrLq1, Per1, KdsSr1);

%below code calculates new IsoRatio of anatectic MELT (is also the same for PERITECTIC phases)
[IsoSr_Liq1] = IsoLiq_E8calc(Sr_WRbulk, 100, IsoSr_WR', Rst1, Sr_WRi, IsoSr_WRi, Liq1, c_SrLq1, Per1, cP1_Sr);
[IsoNd_Liq1] = IsoLiq_E8calc(Nd_WRbulk, 100, IsoNd_WR', Rst1, Nd_WRi, IsoNd_WRi, Liq1, c_NdLq1, Per1, cP1_Nd);

%below code calculates new IsoRatio of bulk unmelted RESTITE phases
[IsoSr_Rst] = IsoRest_calc(Rst1, Sr_WRi, IsoSr_WRi);
[IsoNd_Rst] = IsoRest_calc(Rst1, Nd_WRi, IsoNd_WRi);

%below code calculates new IsoRatio of ENTIRE WR subsystem AFTER AFC1
[IsoSr_WR1] = IsoWRsys_calc(Sr_WRbulk, sum(WRo_X, 'omitnan'), IsoSr_WR', c_SrLq1, Liq1, IsoSr_Liq1, Rst1, Per1, cWR1_Sr);
[IsoNd_WR1] = IsoWRsys_calc(Nd_WRbulk, sum(WRo_X, 'omitnan'), IsoNd_WR', c_NdLq1, Liq1, IsoNd_Liq1, Rst1, Per1, cWR1_Nd);


%% AFC Step 1 - Changes to M subsystem

%below code calculates new TE composition of CONTAMINATED Magma after assimilation of Liq->M
[~, cBa_Mnew] = cM_E9calc('Ba', RowWR_Orig, MCS_TEOut.data, Liq1, c_BaLq1);
[~, cNd_Mnew] = cM_E9calc('Nd', RowWR_Orig, MCS_TEOut.data, Liq1, c_NdLq1);
[~, cRb_Mnew] = cM_E9calc('Rb', RowWR_Orig, MCS_TEOut.data, Liq1, c_RbLq1);
[~, cSm_Mnew] = cM_E9calc('Sm', RowWR_Orig, MCS_TEOut.data, Liq1, c_SmLq1);
[m_Mnew, cSr_Mnew] = cM_E9calc('Sr', RowWR_Orig, MCS_TEOut.data, Liq1, c_SrLq1);

%below code calculates new Isotopic Ratios of CONTAMINATED Magma after assimilation of Liq->M
[IsoSr_M1] = IsoMnew_E10calc('Sr', RowWR_Orig, MCS_TEOut.data, Liq1, c_SrLq1, IsoSr_Liq1, cSr_Mnew);
[IsoNd_M1] = IsoMnew_E10calc('Nd', RowWR_Orig, MCS_TEOut.data, Liq1, c_NdLq1, IsoNd_Liq1, cNd_Mnew);


%% FC Step 1 - Changes to M subsystem (FC'ing of xls DURING AFC step) + FC'ing of xls BETWEEN AFC steps (FC-only step)

%below code selects cols w/ data for masses of cpx, fl, opx, & pl that are FC'd FROM the M subsystem during AFC
FMend = size(MCS_TEOut.data,2);
FMst = FMend - 3;
Fxd_Mins = MCS_TEOut.data(:,FMst:FMend);

%below code creates vector with only Kds of fractionating phases
KdsBa3 = [KdsBa1(5), KdsBa1(6), KdsBa1(13), KdsBa1(14)];
KdsNd3 = [KdsNd1(5), KdsNd1(6), KdsNd1(13), KdsNd1(14)];
KdsRb3 = [KdsRb1(5), KdsRb1(6), KdsRb1(13), KdsRb1(14)];
KdsSm3 = [KdsSm1(5), KdsSm1(6), KdsSm1(13), KdsSm1(14)];
KdsSr3 = [KdsSr1(5), KdsSr1(6), KdsSr1(13), KdsSr1(14)];

%below code uses Mfxn_Calc function to calculate the new mass & TE concentrations of M subsystem AFTER FC-ing out SOME xls
[cBa_Mfc1, ~] = Mfxn_Calc(KdsBa3, cBa_Mnew, Fxd_Mins, m_Mnew, RowAFC_Onset);
[cNd_Mfc1, ~] = Mfxn_Calc(KdsNd3, cNd_Mnew, Fxd_Mins, m_Mnew, RowAFC_Onset);
[cRb_Mfc1, ~] = Mfxn_Calc(KdsRb3, cRb_Mnew, Fxd_Mins, m_Mnew, RowAFC_Onset);
[cSm_Mfc1, ~] = Mfxn_Calc(KdsSm3, cSm_Mnew, Fxd_Mins, m_Mnew, RowAFC_Onset);
[cSr_Mfc1, m_Mfc1] = Mfxn_Calc(KdsSr3, cSr_Mnew, Fxd_Mins, m_Mnew, RowAFC_Onset);

%below code changes row data sourced from <- for the SECOND FC step (between AFC increments)
FCrow = RowAFC_Onset + 1;

%below code uses Mfxn_Calc function to calculate the new mass & TE concentrations of M subsystem AFTER FC-ing out SOME xls
[cBa_Mfc2, ~] = Mfxn_Calc(KdsBa3, cBa_Mfc1, Fxd_Mins, m_Mfc1, FCrow);
[cNd_Mfc2, ~] = Mfxn_Calc(KdsNd3, cNd_Mfc1, Fxd_Mins, m_Mfc1, FCrow);
[cRb_Mfc2, ~] = Mfxn_Calc(KdsRb3, cRb_Mfc1, Fxd_Mins, m_Mfc1, FCrow);
[cSm_Mfc2, ~] = Mfxn_Calc(KdsSm3, cSm_Mfc1, Fxd_Mins, m_Mfc1, FCrow);
[cSr_Mfc2, m_Mfc2] = Mfxn_Calc(KdsSr3, cSr_Mfc1, Fxd_Mins, m_Mfc1, FCrow);


%% AFC Step 2 - Accounting of Changes in WR Mineral Assemblage

%below code changes row data sourced from <- for the SECOND AFC step
AFC2row = FCrow + 1;

%below code assembles a matrix where col1 = unmelted WRi & col2 = unmelted peritectic phases from AFC1
Peri1_Phz = Per1;
Peri1_Phz(2) = Liq1(2);
WR_Phz = horzcat(Rst1, Peri1_Phz);

%below code pulls data for state of WR AFTER second AFC step
Rst2 = (MCS_TEOut.data(AFC2row, 7:22))';                %Rst2 = TOTAL masses of phases present in WR2 after AFC
WR1all = sum(WR_Phz,2);

%below code identifies NEWLY GROWN peritectic phases
delWR2 = Rst2 - WR1all;                                 %delWR2 = net rxn for each phase (growth or dissolution)
delWR2(1:2,1) = 0;
IdxP2 = delWR2 > 0;                                     %IdxP = location of peritectic SOLIDS (no melt included)  
ckP2 = (IdxP1 ~= IdxP2) & (IdxP2 == 0);                 %ckP2 = location of peritectic phases which MELT (to some degree)

%below code assigns masses of phases (using delWR2)
Per1go = zeros(size(IdxP2));
Per1stay = zeros(size(Per1go));
Per2 = zeros(size(delWR2));
DelWR2 = delWR2;
WRi_go = Per2;


if strcmp(AFCBase, '21SepF') 
    for kk = 1:size(delWR2,1)
        if delWR2(kk,1) >= 0
            Per1stay(kk,1) = Per1(kk,1);
        elseif delWR2(kk,1) < 0 & ckP2(kk,1) == 1
            Per1stay(kk,1) = Per1(kk,1) + delWR2(kk,1);            %Per1stay = mass of OLD peritectic phase REMAINING after some has melted
        end
    end
    for kk = 1:size(ckP2,1)
        if ckP2(kk,1) == 1
            WRi_go(kk,1) = Per1stay(kk,1);                          %WRi_go = mass of WRi phases that contribute to the melt
            Per1go(kk,1) = abs(delWR2(kk,1)) - abs(Per1stay(kk,1)); %Per1go = mass of peritectic phases which contribute to the melt
            Per1stay(kk,1) = Per1(kk,1) - Per1go(kk,1);             %Per1stay = mass of OLD peritectic phase REMAINING after some has melted
        elseif ckP2(kk,1) == 0 
            WRi_go(kk,1) = DelWR2(kk,1);
        end
    end
    Per2 = Rst2 - Rst1 - Per1;                                      %Per2 = newly GROWN peritectic phases
    Per2(Per2<0) = 0;
    WRi_go(WRi_go > 0) = 0;
    DelWR2(DelWR2>0) = 0;
    WRi_Rst = Rst1 + WRi_go;                                        %WRi_Rst = mass of UNMELTED WRi phases REMAINING after AFC
    Liq2 = Rst2(1:2);

elseif strcmp(AFCBase, '22SepA')
    for kk = 1:size(delWR2,1)
        if delWR2(kk,1) >= 0
            Per1stay(kk,1) = Per1(kk,1);                            %Per1stay = mass of OLD peritectic phase REMAINING after some has melted
            DelWR2(kk,1) = 0;
        elseif delWR2(kk,1) < 0 & ckP2(kk,1) == 1
            Per1stay(kk,1) = Per1(kk,1) + delWR2(kk,1);             %Per1stay = mass of OLD peritectic phase REMAINING after some has melted
            Per1go(kk,1) = abs(delWR2(kk,1));                       %Per1go = mass of peritectic phases which contribute to the melt
            DelWR2(kk,1) = 0;
        end
    end
    Per2 = Rst2 - Rst1 - Per1;                                      %Per2 = newly GROWN peritectic phases
    Per2(Per2<0) = 0;               
    WRi_go = DelWR2;                                                %WRi_go = mass of WRi phases that contribute to the melt
    WRi_Rst = Rst1 + DelWR2;                                        %WRi_Rst = mass of UNMELTED WRi phases REMAINING after AFC
    Liq2 = Rst2(1:2);

elseif strcmp(AFCBase, '22SepB')
    for kk = 1:size(delWR2,1)
        if delWR2(kk,1) >= 0
            Per1stay(kk,1) = Per1(kk,1);
            DelWR2(kk,1) = 0;
        elseif delWR2(kk,1) < 0 & ckP2(kk,1) == 1
            Per1stay(kk,1) = Per1(kk,1) + delWR2(kk,1);
            Per1go(kk,1) = abs(delWR2(kk,1));
            DelWR2(kk,1) = 0;
        end
    end
    Per2 = Rst2 - Rst1 - Per1;
    Per2(Per2<0) = 0;
    WRi_go(WRi_go > 0) = 0;
    WRi_Rst = Rst1 + DelWR2;
    Liq2 = Rst2(1:2);
else
end


%below code makes matrices of mineral assemblages
WR2_Phz = horzcat(WRi_Rst, Per1stay, Per2);             %WR2_Phz = phases present in WR2 AFTER AFC Step#2
Liq2_Phz = horzcat(WRi_go, abs(Per1go));                %Liq2_Phz = phases that CONTRIBUTED to form Liq#2
WR2_Phz(1:2,:) = 0;



%% AFC Step 2 - Changes to WR subsystem

%below code uses the cLiq_E12calc function (see Appdx E) to calculate the new TE concentration in 
%newly-generated melt & peritectic phases
[cBa_Liq2, cBa_Per2] = cLiq_E12calc(Liq2_Phz, Ba_WRi, cP1_Ba, Liq1, c_BaLq1, Per2, Liq2, KdsBa1);
[cNd_Liq2, cNd_Per2] = cLiq_E12calc(Liq2_Phz, Nd_WRi, cP1_Nd, Liq1, c_NdLq1, Per2, Liq2, KdsNd1);
[cRb_Liq2, cRb_Per2] = cLiq_E12calc(Liq2_Phz, Rb_WRi, cP1_Rb, Liq1, c_RbLq1, Per2, Liq2, KdsRb1);
[cSm_Liq2, cSm_Per2] = cLiq_E12calc(Liq2_Phz, Sm_WRi, cP1_Sm, Liq1, c_SmLq1, Per2, Liq2, KdsSm1);
[cSr_Liq2, cSr_Per2] = cLiq_E12calc(Liq2_Phz, Sr_WRi, cP1_Sr, Liq1, c_SrLq1, Per2, Liq2, KdsSr1);

%below code uses the cWR_E13calc function (see Appdx E) to calculate new TE concentration of the bulk WR subsystem after AFC
[cBa_WR2, ~] = cWR_E13calc(WR2_Phz, Ba_WRi, Liq2, cBa_Liq2, cP1_Ba, cBa_Per2);
[cNd_WR2, ~] = cWR_E13calc(WR2_Phz, Nd_WRi, Liq2, cNd_Liq2, cP1_Nd, cNd_Per2);
[cRb_WR2, ~] = cWR_E13calc(WR2_Phz, Rb_WRi, Liq2, cRb_Liq2, cP1_Rb, cRb_Per2);
[cSm_WR2, ~] = cWR_E13calc(WR2_Phz, Sm_WRi, Liq2, cSm_Liq2, cP1_Sm, cSm_Per2);
[cSr_WR2, m_WR2] = cWR_E13calc(WR2_Phz, Sr_WRi, Liq2, cSr_Liq2, cP1_Sr, cSr_Per2);

%below code uses the cWR_E15calc function (see Appdx E) to calculate new TE concentration of newly-generated anatectic melt
[IsoSr_Liq2] = isoLiq_E15calc(Liq2_Phz, Sr_WRi, IsoSr_WRi, cP1_Sr, Liq1, c_SrLq1, IsoSr_Liq1, Per2, Liq2, KdsSr1, cSr_Liq2);
[IsoNd_Liq2] = isoLiq_E15calc(Liq2_Phz, Nd_WRi, IsoNd_WRi, cP1_Nd, Liq1, c_NdLq1, IsoNd_Liq1, Per2, Liq2, KdsNd1, cNd_Liq2);

%below code uses the isoWR_calc function (see Appdx E) to calculate new IsoSig of bulk WR subsystem after AFC
[IsoSr_WR2] = isoWR_calc(WR2_Phz, Sr_WRi, IsoSr_WRi, cP1_Sr, IsoSr_Liq1, cSr_Per2, Liq2, cSr_Liq2, IsoSr_Liq2, cSr_WR2);
[IsoNd_WR2] = isoWR_calc(WR2_Phz, Nd_WRi, IsoNd_WRi, cP1_Nd, IsoNd_Liq1, cNd_Per2, Liq2, cNd_Liq2, IsoNd_Liq2, cNd_WR2);


%% AFC Step 2 - Changes to M subsystem

%below code calculates new TE composition of CONTAMINATED Magma after assimilation of Liq->M
[~, cBa_M2new] = cM_postAFC(m_Mfc2, cBa_Mfc2, Liq2, cBa_Liq2);
[~, cNd_M2new] = cM_postAFC(m_Mfc2, cNd_Mfc2, Liq2, cNd_Liq2);
[~, cRb_M2new] = cM_postAFC(m_Mfc2, cRb_Mfc2, Liq2, cRb_Liq2);
[~, cSm_M2new] = cM_postAFC(m_Mfc2, cSm_Mfc2, Liq2, cSm_Liq2);
[m_M2new, cSr_M2new] = cM_postAFC(m_Mfc2, cSr_Mfc2, Liq2, cSr_Liq2);

%below code calculates new Isotopic Ratios of CONTAMINATED Magma after assimilation of Liq->M
[IsoSr_M2] = IsoM_postAFC(m_Mfc2, cSr_Mfc2, IsoSr_M1, Liq2, cSr_Liq2, IsoSr_Liq2, cSr_M2new);
[IsoNd_M2] = IsoM_postAFC(m_Mfc2, cNd_Mfc2, IsoNd_M1, Liq2, cNd_Liq2, IsoNd_Liq2, cNd_M2new);



%% FC Step 2 - Changes to M subsystem (FC'ing of xls DURING AFC step) + FC'ing of xls BETWEEN AFC steps (FC-only step)

%below code uses Mfxn_Calc function to calculate the new mass & TE concentrations of M subsystem AFTER FC-ing out SOME xls
[cBa_Mfc3, ~] = Mfxn_Calc(KdsBa3, cBa_M2new, Fxd_Mins, m_M2new, AFC2row);
[cNd_Mfc3, ~] = Mfxn_Calc(KdsNd3, cNd_M2new, Fxd_Mins, m_M2new, AFC2row);
[cRb_Mfc3, ~] = Mfxn_Calc(KdsRb3, cRb_M2new, Fxd_Mins, m_M2new, AFC2row);
[cSm_Mfc3, ~] = Mfxn_Calc(KdsSm3, cSm_M2new, Fxd_Mins, m_M2new, AFC2row);
[cSr_Mfc3, m_Mfc3] = Mfxn_Calc(KdsSr3, cSr_M2new, Fxd_Mins, m_M2new, AFC2row);

%below code changes row data sourced from <- for the SECOND FC step (between AFC increments)
FC2row = AFC2row + 1;

%below code uses Mfxn_Calc function to calculate the new mass & TE concentrations of M subsystem AFTER FC-ing out SOME xls
[cBa_Mfc4, ~] = Mfxn_Calc(KdsBa3, cBa_Mfc3, Fxd_Mins, m_Mfc3, FC2row);
[cNd_Mfc4, ~] = Mfxn_Calc(KdsNd3, cNd_Mfc3, Fxd_Mins, m_Mfc3, FC2row);
[cRb_Mfc4, ~] = Mfxn_Calc(KdsRb3, cRb_Mfc3, Fxd_Mins, m_Mfc3, FC2row);
[cSm_Mfc4, ~] = Mfxn_Calc(KdsSm3, cSm_Mfc3, Fxd_Mins, m_Mfc3, FC2row);
[cSr_Mfc4, m_Mfc4] = Mfxn_Calc(KdsSr3, cSr_Mfc3, Fxd_Mins, m_Mfc3, FC2row);


%% AFC Step 3 - Accounting of Changes in WR Mineral Assemblage

%below code changes row data sourced from <- for the THIRD AFC step
AFC3row = FC2row + 1;

%below code removes mass of liq->M from WR2Phases variable created at end of last AFC step
WR2_Phz(1,end) = 0;

%below code pulls data for state of WR AFTER third AFC step
Rst3 = (MCS_TEOut.data(AFC3row, 7:22))';                %Rst3 = TOTAL masses of phases present in WR3 after AFC
WR2all = sum(WR2_Phz,2);

%below code identifies NEWLY GROWN peritectic phases
delWR3 = Rst3 - WR2all;                                 %delWR3 = net rxn for each phase (growth or dissolution)
delWR3(1:2,1) = 0;

IdxP3 = delWR3 > 0;                                     %IdxP = location of peritectic SOLIDS (no melt included)  
ckP3 = (IdxP2 ~= IdxP3) & (IdxP3 == 0);                 %ckP3 = location of peritectic phases which MELT (to some degree)
cKp3 = abs(delWR3) <= Per2;                             %cKp3 is a mid-step variable to help calculate the mass of periGO phases

%below code assigns masses of phases (using delWR3)
Per2go = zeros(size(IdxP3));
Per2stay = zeros(size(Per2go));
Per3 = zeros(size(delWR3));
Liq3 = Per3;
DelWR3 = delWR3;
DelWR3(DelWR3>0) = 0;

%below code apportions different masses of different peritectic phases during back-rxn in AFCWR3
if strcmp(AFCBase, '21SepF') 
    for kk = 1:size(delWR3,1)
        if delWR3(kk,1) >= 0
            Per2stay(kk,1) = Per2(kk,1);
            Per2stay(1:2,1) = 0;
        elseif delWR3(kk,1) < 0 & ckP3(kk,1) == 1
            Per2stay(kk,1) = Per2(kk,1) + delWR3(kk,1);            %Per2stay = mass of OLD peritectic phase REMAINING after some has melted
            Per2stay(1:2,1) = 0
        elseif ckP3(kk,1) == 0
            Per2go(kk,1) = 0;
            WRi_go(kk,1) = DelWR3(kk,1);                           %WRi_go = mass of WRi phases that contribute to the melt
        end
    end
    WRi_Rst = (Rst2 + WRi_go) - Per2stay - Per1stay;               %WRi_Rst = mass of UNMELTED WRi phases REMAINING after AFC
    Per3 = Rst3 - WRi_Rst - Per2stay - Per1stay;                   %Per3 = newly GROWN peritectic phases
    Per3(Per3<0) = 0;
    Liq3 = Rst3(1:2);
    Liq3_Phz = WRi_go;                                           %Liq3_Phz = phases that CONTRIBUTED to form Liq#2

    
elseif strcmp(AFCBase, '22SepA')
    for kk = 1:size(delWR3,1)
        if ckP3(kk,1) == 1
            Per2go(kk,1) = delWR3(kk,1);                      %Per2go = mass of OLD peritectic phase MELTED - INCLUDING LIQUID!!!
            Per2stay(kk,1) = Per2(kk,1) + delWR3(kk,1);       %Per2stay = mass of OLD peritectic phase REMAINING after some has melted
            DelWR3(kk,1) = 0;
        else
        end
        if IdxP3(kk,1) == 1
            Per3(kk,1) = delWR3(kk,1);                        %Peri3 = mass of new peritectic growth
            Per2stay(kk,1) = Per2(kk,1);
            DelWR3(kk,1) = 0;
        else
        end
    end
        Liq3 = Rst3(1:2);
        WRi_Rst = WRi_Rst + DelWR3;
        WRi_go = DelWR3;
        Liq3_Phz = horzcat(WRi_go, Per2go);                    %Liq3_Phz = phases that CONTRIBUTED to form Liq#2

    
elseif strcmp(AFCBase, '22SepB')    
    for kk = 1:size(delWR3,1)
        if ckP3(kk,1) == 1
            Per2go(kk,1) = delWR3(kk,1);                      %Per2go = mass of OLD peritectic phase MELTED - INCLUDING LIQUID!!!
            Per2stay(kk,1) = Per2(kk,1) + delWR3(kk,1);       %Per2stay = mass of OLD peritectic phase REMAINING after some has melted
            DelWR3(kk,1) = 0;
        else
        end
        if IdxP3(kk,1) == 1
            Per3(kk,1) = delWR3(kk,1);                        %Peri3 = mass of new peritectic growth
            Per2stay(kk,1) = Per2(kk,1);
            DelWR3(kk,1) = 0;
        else
        end
    end
    
    IdxP1a = Per1stay > 0;
    IdxDel = DelWR3 < 0;
    cKp1 = (IdxDel == IdxP1a) & (IdxP1a == 1);
    
    for kk = 1:size(Per1stay)
        if cKp1(kk,1) == 1
            Per1stay(kk,1) = Per1stay(kk,1) + DelWR3(kk,1);                        %Peri3 = mass of new peritectic growth
            Per1go(kk,1) = DelWR3(kk,1);
            DelWR3(kk,1) = 0;
        else
            Per1stay(kk,1) = Per1stay(kk,1);
        end
    end
        Liq3 = Rst3(1:2);
        WRi_Rst = WRi_Rst + DelWR3;
        WRi_go = DelWR3;
        Liq3_Phz = horzcat(WRi_go, -Per1go, Per2go);                 %Liq3_Phz = phases that CONTRIBUTED to form Liq#2
end


%below code makes matrices of mineral assemblages
WR3_Phz = horzcat(WRi_Rst, Per1stay, Per2stay, Per3);       %WR3_Phz = phases present in WR2 AFTER AFC Step#2
WR3_Phz(1:2,:) = 0;
%WR3_Phz(1:2,3) = Liq2;

%below code checks to make sure final mineral assemblage acheives mass closure w/ MCS Output for AFC step #3
cKout = sum(WR3_Phz,2) == Rst3;
for j = 3:length(cKout)
    if cKout(j,1) ~= 1
        error('Mineral Assemblage does NOT achieve mass closure!')
    else
    end
end


%% AFC Step 3 - Changes to WR subsystem

%below code calculates the new TE concentration in newly-generated melt & peritectic phases
if strcmp(AFCBase, '21SepF') 
    [cBa_Liq3, cBa_Per3] = cLiq_AFC3calc(Liq3_Phz, Ba_WRi, Liq2, cBa_Liq2, Per3, Liq3, KdsBa1);
    [cNd_Liq3, cNd_Per3] = cLiq_AFC3calc(Liq3_Phz, Nd_WRi, Liq2, cNd_Liq2, Per3, Liq3, KdsNd1);
    [cRb_Liq3, cRb_Per3] = cLiq_AFC3calc(Liq3_Phz, Rb_WRi, Liq2, cRb_Liq2, Per3, Liq3, KdsRb1);
    [cSm_Liq3, cSm_Per3] = cLiq_AFC3calc(Liq3_Phz, Sm_WRi, Liq2, cSm_Liq2, Per3, Liq3, KdsSm1);
    [cSr_Liq3, cSr_Per3] = cLiq_AFC3calc(Liq3_Phz, Sr_WRi, Liq2, cSr_Liq2, Per3, Liq3, KdsSr1);
elseif strcmp(AFCBase, '22SepA') 
    [cBa_Liq3, cBa_Per3] = cLiq_AFC3calc(Liq3_Phz, Ba_WRi, Liq2, cBa_Liq2, Per3, Liq3, KdsBa1, cBa_Per2);
    [cNd_Liq3, cNd_Per3] = cLiq_AFC3calc(Liq3_Phz, Nd_WRi, Liq2, cNd_Liq2, Per3, Liq3, KdsNd1, cNd_Per2);
    [cRb_Liq3, cRb_Per3] = cLiq_AFC3calc(Liq3_Phz, Rb_WRi, Liq2, cRb_Liq2, Per3, Liq3, KdsRb1, cRb_Per2);
    [cSm_Liq3, cSm_Per3] = cLiq_AFC3calc(Liq3_Phz, Sm_WRi, Liq2, cSm_Liq2, Per3, Liq3, KdsSm1, cSm_Per2);
    [cSr_Liq3, cSr_Per3] = cLiq_AFC3calc(Liq3_Phz, Sr_WRi, Liq2, cSr_Liq2, Per3, Liq3, KdsSr1, cSr_Per2);
elseif strcmp(AFCBase, '22SepB')
    [cBa_Liq3, cBa_Per3] = cLiq_AFC3calc(Liq3_Phz, Ba_WRi, Liq2, cBa_Liq2, Per3, Liq3, KdsBa1, cP1_Ba, cBa_Per2);
    [cNd_Liq3, cNd_Per3] = cLiq_AFC3calc(Liq3_Phz, Nd_WRi, Liq2, cNd_Liq2, Per3, Liq3, KdsNd1, cP1_Nd, cNd_Per2);
    [cRb_Liq3, cRb_Per3] = cLiq_AFC3calc(Liq3_Phz, Rb_WRi, Liq2, cRb_Liq2, Per3, Liq3, KdsRb1, cP1_Rb, cRb_Per2);
    [cSm_Liq3, cSm_Per3] = cLiq_AFC3calc(Liq3_Phz, Sm_WRi, Liq2, cSm_Liq2, Per3, Liq3, KdsSm1, cP1_Sm, cSm_Per2);
    [cSr_Liq3, cSr_Per3] = cLiq_AFC3calc(Liq3_Phz, Sr_WRi, Liq2, cSr_Liq2, Per3, Liq3, KdsSr1, cP1_Sr, cSr_Per2);
end

%below code uses the cWR_E13calc function (see Appdx E) to calculate new TE concentration of the bulk WR subsystem after AFC
[cBa_WR3, ~] = cWR_E13calc(WR3_Phz, Ba_WRi, Liq3, cBa_Liq3, cP1_Ba, cBa_Per2, cBa_Per3);
[cNd_WR3, ~] = cWR_E13calc(WR3_Phz, Nd_WRi, Liq3, cNd_Liq3, cP1_Nd, cNd_Per2, cBa_Per3);
[cRb_WR3, ~] = cWR_E13calc(WR3_Phz, Rb_WRi, Liq3, cRb_Liq3, cP1_Rb, cRb_Per2, cBa_Per3);
[cSm_WR3, ~] = cWR_E13calc(WR3_Phz, Sm_WRi, Liq3, cSm_Liq3, cP1_Sm, cSm_Per2, cBa_Per3);
[cSr_WR3, m_WR3] = cWR_E13calc(WR3_Phz, Sr_WRi, Liq3, cSr_Liq3, cP1_Sr, cSr_Per2, cBa_Per3);

%below code uses the AFC3calc function (see Appdx E) to calculate new TE concentration of newly-generated anatectic melt
if strcmp(AFCBase, '21SepF')
[IsoSr_Liq3] = IsoLiq_AFC3calc(Liq3_Phz, Sr_WRi, IsoSr_WRi, Liq2, cSr_Liq2, IsoSr_Liq2, Per3, Liq3, cSr_Liq3, KdsSr1);
[IsoNd_Liq3] = IsoLiq_AFC3calc(Liq3_Phz, Nd_WRi, IsoNd_WRi, Liq2, cNd_Liq2, IsoNd_Liq2, Per3, Liq3, cNd_Liq3, KdsNd1);
elseif strcmp(AFCBase, '22SepA')
[IsoSr_Liq3] = IsoLiq_AFC3calc(Liq3_Phz, Sr_WRi, IsoSr_WRi, Liq2, cSr_Liq2, IsoSr_Liq2, Per3, Liq3, cSr_Liq3, KdsSr1, cSr_Per2, IsoSr_Liq2);
[IsoNd_Liq3] = IsoLiq_AFC3calc(Liq3_Phz, Nd_WRi, IsoNd_WRi, Liq2, cNd_Liq2, IsoNd_Liq2, Per3, Liq3, cNd_Liq3, KdsNd1, cNd_Per2, IsoNd_Liq2);
elseif strcmp(AFCBase, '22SepB')
[IsoSr_Liq3] = IsoLiq_AFC3calc(Liq3_Phz, Sr_WRi, IsoSr_WRi, Liq2, cSr_Liq2, IsoSr_Liq2, Per3, Liq3, cSr_Liq3, KdsSr1, cP1_Sr, IsoSr_Liq1, cSr_Per2, IsoSr_Liq2);
[IsoNd_Liq3] = IsoLiq_AFC3calc(Liq3_Phz, Nd_WRi, IsoNd_WRi, Liq2, cNd_Liq2, IsoNd_Liq2, Per3, Liq3, cNd_Liq3, KdsNd1, cP1_Nd, IsoNd_Liq1, cNd_Per2, IsoNd_Liq2);
end

%below code uses the isoWR_calc function (see Appdx E) to calculate new IsoSig of bulk WR subsystem after AFC
[IsoSr_WR3] = IsoWR_AFC3calc(WR3_Phz, Sr_WRi, IsoSr_WRi, Liq3, cSr_Liq3, IsoSr_Liq3, cP1_Sr, IsoSr_Liq1, cSr_Per2, IsoSr_Liq2, cSr_Per3, IsoSr_Liq3, cSr_WR3)
[IsoNd_WR3] = IsoWR_AFC3calc(WR3_Phz, Nd_WRi, IsoNd_WRi, Liq3, cNd_Liq3, IsoNd_Liq3, cP1_Nd, IsoNd_Liq1, cNd_Per2, IsoNd_Liq2, cNd_Per3, IsoNd_Liq3, cNd_WR3)



%% AFC Step 3 - Changes to M subsystem

%below code calculates new TE composition of CONTAMINATED Magma after assimilation of Liq->M
[~, cBa_M3new] = cM_postAFC(m_Mfc4, cBa_Mfc4, Liq3, cBa_Liq3);
[~, cNd_M3new] = cM_postAFC(m_Mfc4, cNd_Mfc4, Liq3, cNd_Liq3);
[~, cRb_M3new] = cM_postAFC(m_Mfc4, cRb_Mfc4, Liq3, cRb_Liq3);
[~, cSm_M3new] = cM_postAFC(m_Mfc4, cSm_Mfc4, Liq3, cSm_Liq3);
[m_M3new, cSr_M3new] = cM_postAFC(m_Mfc4, cSr_Mfc4, Liq3, cSr_Liq3);


%below code calculates new Isotopic Ratios of CONTAMINATED Magma after assimilation of Liq->M
[IsoSr_M3] = IsoM_postAFC(m_Mfc4, cSr_Mfc4, IsoSr_M2, Liq3, cSr_Liq3, IsoSr_Liq3, cSr_M3new)
[IsoNd_M3] = IsoM_postAFC(m_Mfc4, cNd_Mfc4, IsoNd_M2, Liq3, cNd_Liq3, IsoNd_Liq3, cNd_M3new)



%% Output of Final Mineral Assemblage

%below code creates Table E3 (INDIVIDUAL PHASES)
T3 = table(WR3_Phz(3:end,:));
T6 = splitvars(T3);                                         %splitvars splits different cols into individual variables
T6.Properties.VariableNames = {'WRi phases', 'Peri1 phases', 'Peri2 phases', 'Peri3 phases'};
T6.Properties.RowNames = R1xls(3:end,:);


%below code prompts user to choose whether or not to output data Excel tables
InPuT1 = 0;
while InPuT1 ~= 1
    TblOut1 = input('Would you like to export FINAL WR conditions? \n','s');
    if strcmp(TblOut1, 'y') || strcmp(TblOut1, 'yes')   
        filename3 = 'AFC_finMins.xlsx';
        writetable(T3, filename3); 
        InPuT1 = 1;

    elseif strcmp(TblOut1, 'n') || strcmp(TblOut1, 'no')
        InPuT1 = 1;
    end  
end


%below code creates Table E4 (NEW contaminated M compositions AFTER AFC has
%taken place.
Mnew1 = vertcat(cBa_M3new, cNd_M3new, cRb_M3new, cSm_M3new, cSr_M3new, IsoSr_M3, IsoNd_M3);
Mnew1(:,12) = [];
T4 = table(Mnew1);
T5 = splitvars(T4);                                         %splitvars splits different cols into individual variables
T5.Properties.VariableNames = {'G01', 'G02', 'G03', 'G04', 'G05', 'G06', 'G08', 'G09', 'G10',...
    'G11', 'G12', 'LB91_136', 'LB91_138', 'LB91_151', 'LB92_155', 'LM93_3210'};



%below code prompts user to choose whether or not to output data Excel tables
InPuT1 = 0;
while InPuT1 ~= 1
    TblOut1 = input('Would you like to export a table of FINAL Magma conditions? \n','s');
    if strcmp(TblOut1, 'y') || strcmp(TblOut1, 'yes')   
        filename5 = 'cMagma_newX.xlsx';
        writetable(T5, filename5); 
        InPuT1 = 1;

    elseif strcmp(TblOut1, 'n') || strcmp(TblOut1, 'no')
        InPuT1 = 1;
    end  
end






